# Street Lines — Skatepark 3D
Protótipo de skate 3D para navegador mobile. Direcional virtual para andar/virar; OLLIE para saltar; FLIP no ar; GRIND experimental.

## Publicar pelo celular
1. Crie um repositório no GitHub e envie `index.html` para a raiz (pode enviar o ZIP extraído pelo site ou criar o arquivo `index.html` e colar o conteúdo).
2. Vá a Settings → Pages → Deploy from a branch → branch `main`, folder `/ (root)` → Save.
3. Aguarde e abra `https://SEU-USUARIO.github.io/NOME-DO-REPO/` no Chrome. Precisa de internet para carregar Three.js da CDN.

Protótipo inicial: modelo estilizado, sem física/colisão avançada. O modo Grind é experimental.
